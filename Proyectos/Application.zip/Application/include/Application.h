#pragma once
#include <vector>
#include <map>
#include <glad.h>

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "GLFW/glfw3.h"

class Application
{

private:

	std::map<std::string, GLuint> ids;
	float time{ 0.0f };
	float move{ 0.0f };
	void setUpGeometry();
	void setUpProgram();


public:

	GLFWwindow* window;
	float direction{ 1.0f };

	void setup();
	void update();
	void draw();

	std::string fileToString(const std::string& filename);

	void keyCallback(int key, int scancode, int action, int mods);
	void SwapDirection();
};